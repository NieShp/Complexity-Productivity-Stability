In the file "empirical_data.xlsx“:
  food_web_number	Food webs number 
  S		Total speciess richness 
  C		Overall connectance 
  Sigma		Overall average interaction strength
  Complexity	Overall complexity measure (Sigma*sqrt(S+C))
  Stability		Food webs stability (local stability, see Appendix S2)
  Fun_Production	Secondary productivity
  C_PH		Connectance between plants and herbivores
  C_PC		Connectance between plants and carnivores
  C_HC		Connectance between herbivores and carnivores
  C_CC		Connectance links within carnivores
  sigma_PH	Mean interaction strength of plants on herbivores
  sigma_PC	Mean interaction strength of plants on carnivores
  sigma_HC	Mean interaction strength of herbivores on carnivores
  sigma_CC	Mean interaction strength within carnivores
  S_P  		Plants richness
  S_H		Herbivores richness
  S_C	    	Carnivores richness

In the file "Overview_of_149_food_webs.xlsx“:
 food_web_number		Food webs number 
 name			The name of the Ecopath food web 
 country			Country of the surveyed food web
 type			Food web tyle (Ecosystem tyle)
 area			Area of the surveyed food web
 longtitude			The longtitude of food web
 latitude			The latitude of food web	
 year			The time of building food webs
 num_group		Total speciess richness or the number of trophic groups
 reference			The original reference that proposed the food web


