function Jaco=Jaco_calculate_approximation(F,B,par)
F=F';
% F is energy flux;  % Fij: i to j, i.e., j eat i
% B=Biomass;
n=size(F,1);
J=zeros(n,n);
s=0;
for i=1:n
    for j=1:n
        if F(i,j)~=0 && F(j,i)==0  % j eat i and i do not eat j
            if i < par.S_b
                e= 0.45;
            else
                e= 0.85;
            end
            J(i,j)=-F(i,j)/B(j);            % j effects i (negative)
            J(j,i)=F(i,j)/B(i)*e;
        end
        
        if F(i,j)~=0 && F(j,i)~=0  %  j eat i and i also eat j
            s=s+1;
            fij_1=-F(i,j)/B(j); % j eat i
            if j<par.S_b
                e=0.45;
            else
                e=0.85;
            end
            fij_2=F(j,i)/B(j)*e; 
            J(i,j)=fij_1+fij_2;   % j effect i
            fji_2=-F(j,i)/B(i);   % i eat j
            if i<par.S_b
                e=0.45;
            else
                e=0.85;
            end
            fji_1=F(i,j)/B(i)*e;
            J(j,i)=fji_1+fji_2;   % i effect j
        end
    end
end
Jaco=J;
K=find(B<1e-6);
Jaco(K,:)=0;Jaco(:,K)=0;

