function a=Jacobin_element(i,j,k,Bp,Ba,par,D)
% Fij*Ai 对 Qk 求导， i吃j
L=par.LL;
q=par.q;
z=par.c;
ow=[zeros(par.S_b,1);par.wi];
m=par.S_b;
n=par.S_c;
d=D(i);
A=par.bij;
H=[zeros(m,(m+n));par.hij];
B=[Bp,Ba];
if i==j            % i eat i
    if L(i,k)~=1   % i do not eat k
        a=0;
    end
    if L(i,k)==1   % i eat k
        if k~=i
            a=(-ow(i)*A(i,j)*B(j)^(1+q)*ow(i)*H(i,k)*A(i,k)*(1+q)*B(k)^q)/d^2*B(i);
        else
            a=(ow(i)*A(i,i)*B(i)^(1+q)*(2+q)*d-ow(i)*A(i,i)*B(i)^(2+q)*(z+ow(i)*H(i,i)*A(i,i)*(1+q)*B(i)^q))/d^2;
        end
    end
end
if i~=j
    if k~=i && k~=j
        if L(i,k)~=1
            a=0;
        else
            a=(-ow(i)*A(i,j)*B(j)^(1+q)*ow(i)*H(i,k)*A(i,k)*(1+q)*B(k)^q)/d^2*B(i);
        end
    elseif k~=i && k==j
        a=(ow(i)*A(i,j)*B(j)^(1+q)*(2+q)*d-ow(i)*A(i,k)*B(k)^(1+q)*ow(i)*A(i,k)*H(i,k)*(1+q)*B(k)^q)/d^2;
    elseif k==i && k~=j
        a=-ow(i)*A(i,j)*B(j)^(2+q)*z/d^2;
    end
end


