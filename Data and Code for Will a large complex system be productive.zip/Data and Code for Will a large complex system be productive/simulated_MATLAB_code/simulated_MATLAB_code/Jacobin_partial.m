function Jaco=Jacobin_partial(Bp,Ba,par,N)
J1=zeros(par.S_b+par.S_c);
J2=zeros(par.S_b+par.S_c);
J3=zeros(par.S_b+par.S_c);
B=[Bp,Ba];
ind1 = 1:par.S_b;
ind2 = (par.S_b + 1) : (par.S_b + par.S_c);
Pj = B(ind1)';
Ai = B(ind2)';
bij_B = par.bij * diag([Pj;Ai].^(1+par.q)); 
D = [zeros(par.S_b,1); 1  + par.c .* Ai + par.wi .* sum(par.hij .* bij_B(ind2,:),2)];
L=par.LL;
a=0;
for i=1:par.S_b
    for j=1:par.S_b+par.S_c
        for k=1:par.S_b+par.S_c
            if L(k,i)==1
                a=a+Jacobin_element(k,i,j,Bp,Ba,par,D);
            end
        end
        J1(i,j)=-a;
        a=0;
    end
end
a=0;
for i=1+par.S_b:par.S_b+par.S_c
    for j=1:par.S_b+par.S_c
        for k=1:par.S_b+par.S_c
            if L(i,k)==1
                if j<=par.S_b
                    a=a+par.eP*Jacobin_element(i,k,i,Bp,Ba,par,D);
                else
                    a=a+par.eA*Jacobin_element(i,k,i,Bp,Ba,par,D);
                end
            end
        end
        J2(i,j)=a;
        a=0;
    end
end
a=0;
for i=1+par.S_b:par.S_b+par.S_c
    for j=1:par.S_b+par.S_c
        for k=1:par.S_b+par.S_c
            if L(k,i)==1
                a=a-Jacobin_element(k,i,j,Bp,Ba,par,D);
            end
        end
        J3(i,j)=-a;
        a=0;
    end
end
Nl = N;
NN = Nl(:,ones(par.S_b,1));
Gj = min(NN./(par.Klj+NN),[],1);
r_Pj = par.rj.*Gj';
Jaco=J1+J2+J3;
Jaco=Jaco-diag([par.xP;par.xA])+diag([r_Pj;zeros(par.S_c,1)]);
Jaco(B(:)<1e-6,B(:)<1e-6)=0;