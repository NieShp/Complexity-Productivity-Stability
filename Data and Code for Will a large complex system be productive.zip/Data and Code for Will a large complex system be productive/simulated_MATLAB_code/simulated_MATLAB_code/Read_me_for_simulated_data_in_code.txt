In MATLAB code (allometric scaling, Table S1) :
  S_initial		Initial species richness
  C_initial		Initial food web connectance
  Hill.exponent	Hill exponent (see eqn (3))
  S		Realized food web richness
  C		Realized food web overall connectance
  Sigma_partial	Realized mean average strength (calculated form exact partial differentials, Appendix S2)
  Complexity_partial	Overall complexity measure (calculated form exact partial differentials, Appendix S2)
  Sigma_energy	Realized mean average strength (calculated form approximation, Appendix S2)
  Complexity_energy	Overall complexity measure (calculated form approximation, Appendix S2)
  Biomass		Ecosystem functioning: total biomass
  Primary_prod	Ecosystem functioning: primary productivity
  Second_prod	Ecosystem functioning: second productivity
  S_P		Realized plant richness
  S_H		Realized plant richness	
  S_C		Realized plant richness	
  C_PH		Connectance between plants and herbivores
  C_PC		Connectance between plants and carnivores
  C_HC		Connectance between herbivores and carnivores
  C_CC		Connectance links within carnivores
  sigma_PH_partial	Mean interaction strength of plants on herbivores (calculated form exact partial differentials, Appendix S2)
  sigma_PC_partial	Mean interaction strength of plants on carnivores (calculated form exact partial differentials, Appendix S2)
  sigma_HC_partial	Mean interaction strength of herbivores on carnivores (calculated form exact partial differentials, Appendix S2)
  sigma_CC_partial	Mean interaction strength within carnivores (calculated form exact partial differentials, Appendix S2)
  sigma_PH_energy	Mean interaction strength of plants on herbivores (calculated form approximation, Appendix S2)
  sigma_PC_energy	Mean interaction strength of plants on carnivores (calculated form approximation, Appendix S2)
  sigma_HC_energy	Mean interaction strength of herbivores on carnivores (calculated form approximation, Appendix S2)
  sigma_CC_energy	Mean interaction strength within carnivores (calculated form approximation, Appendix S2)
  stability_partial	Food webs stability (calculated form exact partial differentials, Appendix S2)
  stability_energy        Food webs stability (calculated form approximation, Appendix S2)
