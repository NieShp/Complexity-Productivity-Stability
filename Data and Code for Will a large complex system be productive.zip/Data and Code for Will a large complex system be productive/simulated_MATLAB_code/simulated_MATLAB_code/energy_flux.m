function [Eneygy_PH,Energy_PC,Energy_HC,Energy_CC]=energy_flux(par,Ffij,P_index, H_index, C_index)
par.LL(par.LL(:)~=0)=1;
m=par.S_b;n=par.S_c;
A=par.LL;
Eneygy_PH=0;Energy_PC=0;Energy_HC=0;Energy_CC=0;
p=P_index;h=H_index;c=C_index;
for i=1:m+n
    for j=1:m+n
        if A(i,j)==1
            if ismember(i,h)==1 && ismember(j,p)==1
                Eneygy_PH=Eneygy_PH+Ffij(i,j);
            elseif ismember(i,c)==1 && ismember(j,p)==1
                Energy_PC=Energy_PC+Ffij(i,j);
            elseif ismember(i,c)==1 && ismember(j,h)==1
                Energy_HC=Energy_HC+Ffij(i,j);
            elseif ismember(i,c)==1 && ismember(j,c)==1
                Energy_CC=Energy_CC+Ffij(i,j);
            end
        end
    end
end

                
                
                
                