function [PH_link, PC_link, HC_link, CC_link, L]=foodweb_links(par,P_index, H_index, C_index,B)
% fucntion to calculated the proportion of the feeding links between
% different trophic level
par.LL(par.LL(:)~=0)=1;
m=par.S_b;n=par.S_c;
A=par.LL;
A(B==0,:)=0;A(:,B==0)=0;
L=sum(A(:)==1);
PH=0;PC=0;HC=0;CC=0;
p=P_index;h=H_index;c=C_index;
for i=1:m+n
    for j=1:m+n
        if A(i,j)==1
            if ismember(i,h)==1 && ismember(j,p)==1
                PH=PH+1;
            elseif ismember(i,c)==1 && ismember(j,p)==1
                PC=PC+1;
            elseif ismember(i,c)==1 && ismember(j,h)==1
                HC=HC+1;
            elseif ismember(i,c)==1 && ismember(j,c)==1
                CC=CC+1;
            end
        end
    end
end
PH_link=PH/L;
PC_link=PC/L;
HC_link=HC/L;
CC_link=CC/L;
