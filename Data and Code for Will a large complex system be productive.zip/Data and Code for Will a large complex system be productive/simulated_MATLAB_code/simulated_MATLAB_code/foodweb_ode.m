function dynamics = foodweb_ode(B,par)

ind1 = 1:par.S_b;
ind2 = (par.S_b + 1) : (par.S_b + par.S_c);

Nl = B(1:par.S_r);
Pj = B(par.S_r + ind1);
Ai = B(par.S_r + ind2);
[r_Pj,Fij]=pradation_strength(B,par);

dN = par.D * (par.Sl-Nl) - par.vl*sum(r_Pj);        % resource dynamics
dP = r_Pj - (Ai' * Fij(ind2,ind1))' - par.xP.*Pj;   % basal species dynamics
dA = Ai.*(par.eP*sum(Fij(ind2,ind1),2) + par.eA*sum(Fij(ind2,ind2),2) - par.xA) - (Ai' * Fij(ind2,ind2))';  % consumer dynamics

dynamics = [dN; dP; dA];

dynamics = real(dynamics);
dynamics(B < 1e-6) = -B (B < 1e-6);
% dynamics(B < 1e-6) =0;
end

