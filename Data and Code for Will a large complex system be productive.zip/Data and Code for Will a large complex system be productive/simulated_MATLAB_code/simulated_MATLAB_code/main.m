clear
close all
SIM=50000;
for sim=1:SIM
    % Generate a foodweb using body-mass algorithm (Schneider et al. 2016 Nat Comm)
    par.S_b=round(unidrnd(15)+5);  % initial plant richness
    par.S_c=round(unidrnd(70)+10);  % initial animal richness
    par.R_opt = 100;                    % optimal predator-prey body-mass ratio
    par.ricker = 2;                     % width of the Ricker curve (higher value -> narrower curve)
    par.range_b = [0 4];                % log_10 range; a larger range seems important to maintain more species (because it causes specialists of consumers)
    par.range_c = [2 9];                % log_10 range
    par.f_herbiv  =  0.0;               % fraction of species that are strict herbivores
    par.f_pred  =  0.0;                 % fraction of species that are strict predators
    par.cutoff = 0.01;                   % cutoff of the Ricker curve for setting a link between predator and prey
    par.mass_dist = 'U';                % 'U' - uniform; 'N' - lognormal
    par.linkprob = 0;
    par.linkprob = 0;
    [par.LL, par.mass]=foodweb_generate(par);par.LL(par.LL(:)~=0)=1;S0=par.S_b+par.S_c;C0=sum(par.LL(:)~=0)/S0^2;
    
    Sl_0 = rand*25+25 ;     % initial nutriemnt content
    par.D = 0.25;     % nutrient turnover rate
    par.q = rand;     % Holling exponent
    
    % plant growth rate
    par.rj = 1*par.mass(1:par.S_b).^(-0.25);
    % rsource parameters
    par.S_r = 1;
    par.vl = ones(par.S_r,1);
    
    %% functional response
    par.bij =zeros(par.S_c+par.S_b);
    b0= 50;
    beta_Cons=normrnd(-0.80, 0.00,[S0, 1]);
    beta_Prey=normrnd( 0.25, 0.00,[S0, 1]);
    par.bij=b0*par.mass.^beta_Cons.*(par.mass.^beta_Prey)';
    % par.bij(:,1:par.S_b)=b0*par.mass.^beta_Cons.*(par.mass(1:par.S_b).^beta_Prey(1:par.S_b)*0+10)';
    par.bij=par.bij.*par.LL;
    h0 = 0.001;
    h_Cons=normrnd( 0.47, 0.00, [S0, 1]);
    h_Prey=normrnd(-0.45, 0.00, [S0, 1]);
    par.hij=h0*par.mass.^h_Cons.*(par.mass.^h_Prey)';
    par.hij(1:par.S_b,:)=[];
    Stotal = par.S_r+par.S_b+par.S_c;
    par.wi = 1./sum(par.LL(((par.S_b)+1):end,:)>0,2);
    
    % metabolic rates
    par.xP = 0.138*par.mass(1:par.S_b).^(-0.25);
    par.xA = 0.314*par.mass(par.S_b+1:end).^(-0.25);
    
    % Assimilation rate
    par.c=  0.05;
    par.eP =0.45;
    par.eA =0.85;
    
    %% food web dynamics
    par.Sl =  ones(par.S_r,1).*Sl_0;
    par.Klj = 0.1 + 0.1 * rand(par.S_r,par.S_b);
    B = [(rand(par.S_r,1)+1)/2.*par.Sl; randi([1 10],par.S_b+par.S_c,1)];
    opts2=odeset('reltol',1e-6,'abstol',1e-6,'NonNegative',1:(1*(Stotal)));
    [~,y_B0] = ode15s(@(t,B) foodweb_ode(B,par),[0 1e6],B,opts2);
    y_B0(end,y_B0(end,:)<1e-6)=0;
    
    % Update the current food web
    Bp=y_B0(end,par.S_r+1:par.S_r+par.S_b);
    Ba=y_B0(end,1+par.S_r+par.S_b:end);
    B=[Bp Ba];
    par.LL(:,B==0)=0;par.LL(B==0,:)=0;
    
    % updat feeding
    B=y_B0(end,1:Stotal)';
    ind1 = 1:par.S_b;
    Nl = B(1:par.S_r);
    Pj = B(par.S_r + ind1);
    NN = Nl(:,ones(par.S_b,1));
    Gj = min(NN./(par.Klj+NN),[],1);
    [r_Pj,Fij]=pradation_strength(B,par);
    Ffij=Fij.*B(2:end);
    
    %% Food web properties
    % species richness
    [P_index, H_index, C_index]=trophic_level(Ba,Bp,par);   % identify species trophic level
    P_richness=length(P_index);  % plant richness
    H_richness=length(H_index);  % herbivores richness
    C_richness=length(C_index);  % carnivores richness
    Richness=P_richness+H_richness+C_richness;  % total richness
    
    % food web link between different trophic level
    [PH_link, PC_link, HC_link, CC_link, L]=foodweb_links(par,P_index, H_index, C_index,[Bp,Ba]);
    Conn=L/(Richness^2);   % food web overall connectance
    
    % interaction strength calculated based on Jacobin (energy flux)
    Comm_matrix_energy=Jaco_calculate_approximation(Ffij,[Bp,Ba],par);
    stability_energy=max(real(eig(Comm_matrix_energy)));                    % food web stability
    sigma_energy=mean(abs(Comm_matrix_energy(Comm_matrix_energy(:)~=0)));   % mean of the absolute value of pairwise interaction strength
    complexity_energy=sqrt(Richness*Conn)*sigma_energy;      % Overall complexity
    % the interaction of plant on herbivores
    PH_bio2=Comm_matrix_energy(H_index,P_index);sigma_PH_energy=mean(abs((PH_bio2(PH_bio2(:)~=0))));
    % the interaction of herbivores on plants
    HP_bio2=Comm_matrix_energy(P_index,H_index);sigma_HP_energy=mean(abs((HP_bio2(HP_bio2(:)~=0))));
    % the interaction of plants on carnivores
    PC_bio2=Comm_matrix_energy(C_index,P_index);sigma_PC_energy=mean(abs((PC_bio2(PC_bio2(:)~=0))));
    % the interaction of carnivores on plants
    CP_bio2=Comm_matrix_energy(P_index,C_index);sigma_CP_energy=mean(abs((CP_bio2(CP_bio2(:)~=0))));
    % the interaction of herbivores on carnivores
    HC_bio2=Comm_matrix_energy(C_index,H_index);sigma_HC_energy=mean(abs((HC_bio2(HC_bio2(:)~=0))));
    % the interaction of carnivores on herbivores
    CH_bio2=Comm_matrix_energy(H_index,C_index);sigma_CH_energy=mean(abs((CH_bio2(CH_bio2(:)~=0))));
    % the interaction of carnivores on carnivores
    CC_bio2=Comm_matrix_energy(C_index,C_index);sigma_CC_energy=mean(abs((CC_bio2(CC_bio2(:)~=0))));
       
    % interaction strength calculated based on Jacobin (paratial diff)
    Comm_matrix_partial=Jacobin_partial(Bp,Ba,par,y_B0(end,1))';
    Comm_matrix_partial(Comm_matrix_energy==0)=0;
    stability_partial=max(real(eig(Comm_matrix_partial)));       % food web stability -- without apparent competion
    sigam_partial=mean(abs(Comm_matrix_partial(Comm_matrix_partial(:)~=0)));   % mean of the absolute value of pairwise interaction strength
    complexity_partial=sqrt(Richness*Conn)*sigam_partial;      % Overall complexity
    % the interaction of plant on herbivores
    PH_bio=Comm_matrix_partial(H_index,P_index);sigma_PH_partial=mean(abs((PH_bio(PH_bio(:)~=0))));
    % the interaction of herbivores on plants
    HP_bio=Comm_matrix_partial(P_index,H_index);sigma_HP_partial=mean(abs((HP_bio(HP_bio(:)~=0))));
    % the interaction of plants on carnivores
    PC_bio=Comm_matrix_partial(C_index,P_index);sigma_PC_partial=mean(abs((PC_bio(PC_bio(:)~=0))));
    % the interaction of carnivores on plants
    CP_bio=Comm_matrix_partial(P_index,C_index);sigma_CP_partial=mean(abs((CP_bio(CP_bio(:)~=0))));
    % the interaction of herbivores on carnivores
    HC_bio=Comm_matrix_partial(C_index,H_index);sigma_HC_partial=mean(abs((HC_bio(HC_bio(:)~=0))));
    % the interaction of carnivores on herbivores
    CH_bio=Comm_matrix_partial(H_index,C_index);sigma_CH_partial=mean(abs((CH_bio(CH_bio(:)~=0))));
    % the interaction of carnivores on carnivores
    CC_bio=Comm_matrix_partial(C_index,C_index);sigma_CC_partial=mean(abs((CC_bio(CC_bio(:)~=0))));
    
    %% Ecosystem Functioning
    % biomass
    P_biomass=sum(B(1+P_index));   % plant biomass
    H_biomass=sum(B(1+H_index));   % herbivores biomass
    C_biomass=sum(B(1+C_index));   % carnivores biomass
    Biomass=P_biomass+H_biomass+C_biomass; % Total biomass
    
    % energy from nutrien to plant
    Eenrgy_NP=sum(r_Pj);
    % total feeding with in different trophic levels
    [Eneygy_PH, Energy_PC, Energy_HC, Energy_CC]=energy_flux(par,Ffij,P_index, H_index, C_index);
    

    % initial food webs complexity
    RE(sim,1:3)=[S0, C0, par.q];
    RE(sim,4:9)=[Richness, Conn, sigam_partial, complexity_partial, sigma_energy, complexity_energy];   % complexity
    % fucntioning
    RE(sim,10:12)=[Biomass, Eenrgy_NP, Eneygy_PH+Energy_PC]; % total biomass, primary, second productivity
    % food web feeding links between fidderent trophic level
    RE(sim,13:19)=[P_richness, H_richness, C_richness, PH_link, PC_link, HC_link, CC_link];
    % food web interation strength between fidderent trophic level
    RE(sim,20:26)=[sigma_PH_partial,sigma_HP_partial,sigma_PC_partial,sigma_CP_partial,...
        sigma_HC_partial,sigma_CH_partial,sigma_CC_partial];
    RE(sim,27:33)=[sigma_PH_energy, sigma_HP_energy, sigma_PC_energy, sigma_CP_energy, ...
        sigma_HC_energy, sigma_CH_energy, sigma_CC_energy];
    
    % food web stability
    RE(sim,34:35)=[stability_partial, stability_energy];
end
