function [r_Pj,Fij]=pradation_strength(B,par)
ind1 = 1:par.S_b;
ind2 = (par.S_b + 1) : (par.S_b + par.S_c);

Nl = B(1:par.S_r);
Pj = B(par.S_r + ind1);
Ai = B(par.S_r + ind2);
NN = Nl(:,ones(par.S_b,1));
Gj = min(NN./(par.Klj+NN),[],1);
r_Pj = par.rj.*Gj'.*Pj;
bij_B = par.bij * diag([Pj;Ai].^(1+par.q));         % bij * Rj^(1+q)
scaler_i = par.wi ./ (1  + par.c.* Ai + par.wi .* sum(par.hij .* bij_B(ind2,:),2));
% scaler_i = par.wi ./ par.mass(ind2) ./ (1  + par.c * Ai + par.wi .* sum(par.hij .* bij_B(ind2,:),2));
% scaler_i = par.wi ./ par.mass(ind2) ./(1 + par.c * Ai ./ par.mass(ind2) + par.wi .* sum(par.hij .* bij_B(ind2,:),2));
% scaler_i = par.wi ./(1 + par.wi .* sum(par.hij .* bij_B(ind2,:),2));
% scaler_i = par.wi ./ par.mass(ind2) ./(1 + par.wi .* sum(par.hij .* bij_B(ind2,:),2));
Fij = diag([zeros(par.S_b,1); scaler_i]) * bij_B;