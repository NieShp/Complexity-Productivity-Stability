function [P_index, H_index, C_index]=trophic_level(Ba,Bp,par)
% function to calculate
% the index of plants, herbivores (animal that only eat plants), and carnivores (animal that do not eat plants)
L=par.LL;
m=par.S_b;n=par.S_c;
P_index=[];H_index=[];C_index=[];
ip=0;
for i=1:m
    if Bp(i)>0
        ip=ip+1;
        P_index(ip)=i;
    end
end
K1=sum(L(m+1:m+n,1:m),2);
K2=sum(L(m+1:m+n,1+m:end),2);
i1=0;
i2=0;
for i=1:n
    if Ba(i)>0 && K1(i)~=0 && K2(i)==0
        i1=i1+1;
        H_index(i1)=i+m;
    elseif Ba(i)>0 && K2(i)~=0
        i2=i2+1;
        C_index(i2)=i+m;
    end
end
